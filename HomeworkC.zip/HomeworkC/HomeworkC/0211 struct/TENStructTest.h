//
//  TENStructTest.h
//  Structure
//
//  Created by 444ten on 2/12/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __Structure__TENStructTest__
#define __Structure__TENStructTest__

extern
void TENStructPerformTest();

#endif /* defined(__Structure__TENStructTest__) */
