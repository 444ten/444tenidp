//
//  TENHumanTests.h
//  HomeworkC
//
//  Created by 444ten on 2/17/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __HomeworkC__TENHumanTests__
#define __HomeworkC__TENHumanTests__

extern
void TENHumanPerformTests();

#endif /* defined(__HomeworkC__TENHumanTests__) */
