//
//  TENObjectTests.h
//  HomeworkC
//
//  Created by 444ten on 3/11/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __HomeworkC__TENObjectTests__
#define __HomeworkC__TENObjectTests__

#include <stdio.h>

extern
void TENObjectPerformTest();

#endif /* defined(__HomeworkC__TENObjectTests__) */
