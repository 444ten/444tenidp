//
//  TENCharBitTests.h
//  HomeworkC
//
//  Created by 444ten on 2/22/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __HomeworkC__TENCharBitTests__
#define __HomeworkC__TENCharBitTests__

extern
void TENCharBitPerformTests();

#endif /* defined(__HomeworkC__TENCharBitTests__) */
