//
//  TENEnumerator.c
//  HomeworkC
//
//  Created by 444ten on 3/19/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#include "TENEnumerator.h"

//Set
//  after being created
//      when needed - create Enumerator
//          it should retain Set
//
//      after calling next element of Set
//          Enumerator should check mutation
//          Enumerator should return next element or end of Set
//
//  release Enumerator (with releasing Set)
