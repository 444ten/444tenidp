//
//  TENOutputMacrosTest.c
//  HomeworkC
//
//  Created by 444ten on 2/13/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#include "TENOutputMacros.h"
