//
//  TENStackTests.h
//  HomeworkC
//
//  Created by 444ten on 3/25/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __HomeworkC__TENStackTests__
#define __HomeworkC__TENStackTests__

extern
void TENStackPerformTest();

#endif /* defined(__HomeworkC__TENStackTests__) */
