//
//  TENLinkedListTests.h
//  HomeworkC
//
//  Created by 444ten on 3/26/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __HomeworkC__TENLinkedListTests__
#define __HomeworkC__TENLinkedListTests__

extern
void TENLinkedListPerformTests();

#endif /* defined(__HomeworkC__TENLinkedListTests__) */
