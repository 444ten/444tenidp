//
//  TENValueBitOutputTest.h
//  HomeworkC
//
//  Created by 444ten on 2/15/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __HomeworkC__TENValueBitOutputTest__
#define __HomeworkC__TENValueBitOutputTest__

extern
void TENValueBitOutputPerformTest();

#endif /* defined(__HomeworkC__TENValueBitOutputTest__) */
