//
//  TENAutoreleasePoolTests.h
//  HomeworkC
//
//  Created by 444ten on 4/6/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __HomeworkC__TENAutoreleasePoolTests__
#define __HomeworkC__TENAutoreleasePoolTests__

extern
void TENAutoreleasePoolPerformTests();

#endif /* defined(__HomeworkC__TENAutoreleasePoolTests__) */
