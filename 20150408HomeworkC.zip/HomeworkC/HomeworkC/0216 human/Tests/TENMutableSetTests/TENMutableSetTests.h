//
//  TENMutableSetTests.h
//  HomeworkC
//
//  Created by 444ten on 3/15/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __HomeworkC__TENMutableSetTests__
#define __HomeworkC__TENMutableSetTests__

extern
void TENMutableSetPerformTests();

#endif /* defined(__HomeworkC__TENMutableSetTests__) */
