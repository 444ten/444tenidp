//
//  TENStringTests.h
//  HomeworkC
//
//  Created by 444ten on 3/13/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __HomeworkC__TENStringTests__
#define __HomeworkC__TENStringTests__

extern
void TENStringPerformTest();

#endif /* defined(__HomeworkC__TENStringTests__) */
