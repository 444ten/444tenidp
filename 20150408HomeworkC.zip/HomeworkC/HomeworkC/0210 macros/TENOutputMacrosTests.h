//
//  TENOutputMacrosTests.h
//  HomeworkC
//
//  Created by 444ten on 2/22/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __HomeworkC__TENOutputMacrosTests__
#define __HomeworkC__TENOutputMacrosTests__

extern
void TENOutputMacrosPerformTests();

#endif /* defined(__HomeworkC__TENOutputMacrosTests__) */
