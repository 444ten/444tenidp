//
//  TENCharBit.h
//  charToBin
//
//  Created by 444ten on 2/12/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __charToBin__TENCharToBin__
#define __charToBin__TENCharToBin__

extern
void TENCharBitOutput(char charValue);

#endif /* defined(__charToBin__TENCharToBin__) */
