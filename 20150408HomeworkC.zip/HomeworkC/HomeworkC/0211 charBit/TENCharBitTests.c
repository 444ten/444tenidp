//
//  TENCharBitTests.c
//  HomeworkC
//
//  Created by 444ten on 2/22/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#include <stdio.h>

#include "TENCharBit.h"
#include "TENCharBitTests.h"

void TENCharBitPerformTests() {
    TENCharBitOutput('\0');
    printf("\n");
    TENCharBitOutput(1);
    printf("\n");
    TENCharBitOutput('A');
    printf("\n");
}
