//
//  testOutput.h
//  lesson1
//
//  Created by 444ten on 2/10/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#ifndef __lesson1__testOutput__
#define __lesson1__testOutput__

extern
void TENOutputParentPerformTest();

#endif /* defined(__lesson1__testOutput__) */
